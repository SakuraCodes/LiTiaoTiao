SKIPMOUNT=false
key_source(){
if [[ -e "$1" ]];then
source "$1"
rm -rf "$1"
fi
}
key_source $MODPATH/key.sh
set_perm_recursive  $MODPATH  0  0  0755  0644
set_perm_recursive  $MODPATH/mod  0  0  0755  0777
